# execute this file to play your game once all specs are completed
# no code needs to be written in this file

require_relative "connect_tac_toe"

ConnectTacToe.new(7, 6).play
